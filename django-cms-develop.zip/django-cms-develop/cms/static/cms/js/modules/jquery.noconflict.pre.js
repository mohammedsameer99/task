var __jQuery;
var __$;
// reassign jQuery if jQuery is already loaded
__jQuery = (window.jQuery) ? window.jQuery.noConflict(true) : undefined;
__$ = __jQuery;
