---
name: "\U0001F4A1 Feature requests"
about: Please submit and discuss feature requests via google groups.
title: "[FEATURE]"
labels: 'status: marked for rejection'
assignees: ''

---

<!--
Please submit any feature requests through our developers email list:
https://groups.google.com/forum/#!forum/django-cms-developers
-->
