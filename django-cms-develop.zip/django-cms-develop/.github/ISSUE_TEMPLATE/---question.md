---
name: "\U0001F914 Question"
about: Please use our community channels to ask for questions.
title: ''
labels: 'status: marked for rejection'
assignees: ''

---

<!--
For *help with django CMS*, please use our one of the following channels:

* StackOverflow: https://stackoverflow.com/questions/tagged/django-cms
* Users mailing list: https://groups.google.com/forum/#!forum/django-cms
* #django-cms on freenode.net

Questions submitted through GitHub will be closed. Our community is very
helpful and we try to answer as many questions as you may have.
-->
